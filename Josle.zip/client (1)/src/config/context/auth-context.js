import { createContext } from 'react';

// User signed - null
// user - dispatch
const AuthContext = createContext();
//Hook

export default AuthContext;
