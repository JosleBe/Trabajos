import React, { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import AuthContext from '../../config/context/auth-context';

const Logout = () => {
  const { dispatch } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = () => {

    localStorage.removeItem('token');

   
    dispatch({ type: 'SIGNOUT' });

    navigate('/');
  };

  return (
    <>
      <button onClick={handleLogout}>Cerrar sesión</button>
    </>
  );
};

export default Logout;