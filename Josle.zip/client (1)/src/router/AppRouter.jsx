import React, { useContext } from 'react';
import {
  createBrowserRouter,
  createRoutesFromElements,
  Route,
  RouterProvider,
} from 'react-router-dom';
import SignInPage from '../modules/auth/SignInPage';
import AuthContext from '../config/context/auth-context';
import AdminLayout from '../components/layout/AdminLayout';
const AppRouter = () => {
  const { user } = useContext(AuthContext);
  const routesFromRole = (role) => {
    switch (role) {
      case 'ADMIN_ROLE':
        return (
          <>
            <Route
              path="admin"
              element={
                <>
                {user.user.person && (
                  <>
                    <h1>{user.user.person.name} </h1>
                    <h1>{user.user.person.surname}</h1>
                    {user.user.person.lastname && (
                      <h1>{` ${user.user.person.lastname}`}</h1>
                    )}
                    {user.roles[0] && (
                      <h1>{` - ${user.roles[0].name}`}</h1>
                    )}
                  </>
                )}
              </>
              }
            />
          </>
        );
      case 'CLIENT_ROLE':
        return (
          <Route
            path="client"
            element={
              <>
              {user.user.person && (
                <>
                  <h1>{user.user.person.name} </h1>
                  <h1>{user.user.person.surname}</h1>
                  {user.user.person.lastname && (
                    <h1>{` ${user.user.person.lastname}`}</h1>
                  )}
                  {user.roles[0] && (
                    <h1>{` - ${user.roles[0].name}`}</h1>
                  )}
                </>
              )}
            </>
            }
          />
        );
      case 'USER_ROLE':
        return (
          <Route
            path="user"
            element={
              <>
                {user.user.person && (
                  <>
                    <h1>{user.user.person.name} </h1>
                    <h1>{user.user.person.surname}</h1>
                    {user.user.person.lastname && (
                      <h1>{` ${user.user.person.lastname}`}</h1>
                    )}
                    {user.roles[0] && (
                      <h1>{` - ${user.roles[0].name}`}</h1>
                    )}
                  </>
                )}
              </>
            }
          />
        );
    }
  };
  const router = createBrowserRouter(
    createRoutesFromElements(
      <>
        {user.signed ? (
          <>
            <Route path="/" element={<AdminLayout />}>
              {
                routesFromRole(user?.roles[0]?.name)
              }
              <Route path="dashboard" element={<>Dashboard</>} />
              <Route path="users" element={<>Users</>} />
              <Route path="products" element={<>Products</>} />
            </Route>
          </>
        ) : (
          <Route path="/" element={<SignInPage />} />
        )}
        <Route path="/*" element={<> 404 not found</>} />
      </>
    )
  );
  //RouterProvider -> Context
  return <RouterProvider router={router} />;
};
export default AppRouter;
