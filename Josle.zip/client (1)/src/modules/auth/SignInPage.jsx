

import React, { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import * as yup from 'yup';
import { useFormik } from 'formik';
import { Button, TextInput, Label, Spinner } from 'flowbite-react';
import AxiosClient from '../../config/http-client/axios-client';
import { customAlert } from '../../config/alerts/alert';
import AuthContext from '../../config/context/auth-context';

const SignInPage = () => {
  const { dispatch } = useContext(AuthContext);
  const navigate = useNavigate();

  const formik = useFormik({
    initialValues: {
      username: '',
      password: '',
    },
    validationSchema: yup.object().shape({
      username: yup.string().required('Campo obligatorio'),
      password: yup.string().required('Campo obligatorio'),
    }),
    onSubmit: async (values, { setSubmitting }) => {
      try {
        const response = await AxiosClient({
          url: '/auth/signin',
          method: 'POST',
          data: values,
        });
        console.log(response);
        if (!response.error) {
          /*
                Tienen que validar que rol tiene 
                -> Redireccionarlo a su página principal
            */
           switch (response.data.roles[0].name) {
             case 'ADMIN_ROLE':
               dispatch({ type: 'SIGNIN', payload: response.data });
               navigate('/admin', { replace: true });
               break;
             case 'CLIENT_ROLE':
               dispatch({ type: 'SIGNIN', payload: response.data });
               navigate('/client', { replace: true });
               break;
             case 'USER_ROLE':
               dispatch({ type: 'SIGNIN', payload: response.data });
               navigate('/user', { replace: true });
               break;
           }

        } else throw Error('Error');
      } catch (error) {
        customAlert(
          'Iniciar sesión',
          'Usuario y/o contraseña incorrectos',
          'info'
        );
      } finally {
        setSubmitting(false);
      }
    },
  });

  return (
    <>
      <div className={' w-screen h-screen flex justify-center'}>
      
          <div
            className="flex flex-col items-center px-4 mx-auto"
            style={{ marginTop: '5rem' }}
          >
          
            <div className="w-full bg-white rounded-lg shadow shadow-zinc-300 dark:border md:mt-0 sm:max-w-md xl:p-0 dark:bg-gray-800 dark:border-gray-700">
              <div className="p-6 space-y-4 md:space-y-6 sm:p-8">
             
                <form
                  className="space-y-4 md:space-y-6"
                  onSubmit={formik.handleSubmit}
                  noValidate
                >
                  <div>
                    <Label
                      htmlFor="username"
                      className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                    >
                      Usuario
                    </Label>
                    <TextInput
                      type="text"
                      name="username"
                      value={formik.values.username}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      helperText={
                        formik.errors.username && formik.touched.username ? (
                          <span className="text-red-600">
                            {formik.errors.username}
                          </span>
                        ) : null
                      }
                      id="username"
                      placeholder="erielit"
                    />
                  </div>
                  <div>
                    <Label
                      htmlFor="password"
                      className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                    >
                      Contraseña
                    </Label>
                    <TextInput
                      type="password"
                      name="password"
                      value={formik.values.password}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      helperText={
                        formik.errors.password && formik.touched.password ? (
                          <span className="text-red-600">
                            {formik.errors.password}
                          </span>
                        ) : null
                      }
                      id="password"
                      placeholder="••••••••"
                      required
                    />
                  </div>
                
                  <Button
                    type="submit"
                    color="light"
                    className="w-full"
                    disabled={formik.isSubmitting || !formik.isValid}
                  >
                    {formik.isSubmitting ? (
                      <Spinner />
                    ) : (
                      <>
                      
                     
                        Iniciar sesión
                      </>
                    )}
                  </Button>
                </form>
              </div>
            </div>
          </div>
       
      </div>
    </>
  );
};

export default SignInPage;

